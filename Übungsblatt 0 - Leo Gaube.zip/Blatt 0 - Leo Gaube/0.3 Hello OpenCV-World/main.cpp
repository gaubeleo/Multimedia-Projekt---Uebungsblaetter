#include <iostream>
#include <string>
#include <windows.h>
#include <sys/stat.h>
#include <time.h>
#include <direct.h>

#include <opencv2\core\core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;

Mat loadImg(string directory, string filename){
	string fullFilename = string(directory+"\\"+filename);
	Mat image;
	image = imread(fullFilename, CV_LOAD_IMAGE_COLOR);

	if (!image.data){
		cout << "image file " << fullFilename << " could not be opened" << endl;
		getchar();
		exit(-1);
	}

	return image;
}

Mat writeTextOnImage(string text, int count, Mat img){
	int width, height;
	width = img.cols;
	height = img.rows;

	for (int i = 0; i < count; i++)
		putText(img, text, Point2f(rand()%width, rand()%height), FONT_HERSHEY_COMPLEX, (rand() % 3)+1, Scalar(rand() % 255, rand() % 255, rand() % 255, 255));

	return img;
}

bool saveImg(string directory, string filename, Mat img){
	string fullFilename = string(directory + "\\" + filename);
	struct stat sb;

	if (!(stat(directory.c_str(), &sb) == 0 && sb.st_mode == S_IFDIR)){
		mkdir(directory.c_str());
	}

	return imwrite(fullFilename, img);
}

int main(){
	Mat img, textImg;
	String filename = "lenna.jpg";

	srand(time(NULL));

	img = loadImg("src", filename);

	for (int i : {1, 4, 8}){
		textImg = writeTextOnImage("Hello World!", i, img.clone());
		saveImg("results", to_string(i) + filename, textImg);
	}
	

	return 0;
}