#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <windows.h>
#include <sys/stat.h>
#include <time.h>
#include <vector>
#include <direct.h>
#include <math.h>

#include <opencv2\core\core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;

struct Dimensions{
	int width;
	int height;
};

void displayImage(string fullFilename, Dimensions* d){
	cv::Mat image;
	image = cv::imread(fullFilename, CV_LOAD_IMAGE_COLOR);

	if (!image.data){
		cout << "image file " << fullFilename << " could not be opened" << endl;
		getchar();
		exit(-1);
	}

	imshow(fullFilename, image);
	cv::waitKey(0);
	cv::destroyAllWindows();

	d->width = image.cols;
	d->height = image.rows;
}

vector<string> readTextFile(string directory, string filename){
	string fullFilename = string(directory + "\\" + filename);
	ifstream infile(fullFilename);

	vector<string> filenames = vector<string>();

	string line;
	while (getline(infile, line)){
		filenames.push_back(line);
	}

	return filenames;
}

double calcMedianWidth(vector<Dimensions>& const dims){
	double value = 0;

	for (Dimensions dim : dims){
		value += dim.width;
	}

	return value/dims.size();
}

double calcMedianHeight(vector<Dimensions>& const dims){
	double value = 0;

	for (Dimensions dim : dims){
		value += dim.height;
	}

	return value/dims.size();
}

bool smaller(int i, int j){
	return (i < j);
}

int calcMeanWidth(vector<Dimensions>& const dims){
	vector<int> sortedList = vector<int>();

	for (Dimensions dim : dims){
		sortedList.push_back(dim.width);
	}
	sort(sortedList.begin(), sortedList.end(), smaller);

	return sortedList.at(sortedList.size()/2);
}

int calcMeanHeight(vector<Dimensions>& const dims){
	vector<int> sortedList = vector<int>();

	for (Dimensions dim : dims){
		sortedList.push_back(dim.height);
	}
	sort(sortedList.begin(), sortedList.end(), smaller);

	return sortedList.at(sortedList.size() / 2);
}

double calcVarianceWidth(vector<Dimensions>& const dims){
	double value;
	double E = calcMedianWidth(dims);

	for (Dimensions dim : dims){
		value += (dim.width - E)*(dim.width - E);
	}

	return value / dims.size();
}

double calcVarianceHeight(vector<Dimensions>& const dims){
	double value;
	double E = calcMedianHeight(dims);

	for (Dimensions dim : dims){
		value += (dim.height - E)*(dim.height - E);
	}

	return value/dims.size();
}

double calcStandardDeviationWidth(vector<Dimensions>& const dims){
	return sqrt(calcVarianceWidth(dims));
}

double calcStandardDeviationHeight(vector<Dimensions>& const dims){
	return sqrt(calcVarianceHeight(dims));
}


bool writeTextFile(string directory, string filename, vector<Dimensions>& const dims){
	string fullFilename = string(directory + "\\" + filename);
	struct stat sb;

	if (!(stat(directory.c_str(), &sb) == 0 && sb.st_mode == S_IFDIR)){
		mkdir(directory.c_str());
	}

	ofstream myfile;
	myfile.open(fullFilename);
	myfile << setprecision(2) << std::fixed << std::showpoint;;
	myfile << "Median (width): " << calcMedianWidth(dims) << "px" << endl;
	myfile << "Mean (width): " << calcMeanWidth(dims) << "px" << endl;
	myfile << "Variance (width): " << calcVarianceWidth(dims) << "px" << endl;
	myfile << "Standard Deviation (width): " << calcStandardDeviationWidth(dims) << "px" << endl << endl;
	myfile << "Median (height): " << calcMedianHeight(dims) << "px" << endl;
	myfile << "Mean (height): " << calcMeanHeight(dims) << "px" << endl;
	myfile << "Variance (height): " << calcVarianceHeight(dims) << "px" << endl;
	myfile << "Standard Deviation (height): " << calcStandardDeviationHeight(dims) << "px" << endl;
	myfile.close();

	cout << endl << "median, mean, variance, standard deviation has been written to file: " << fullFilename << endl << endl;

	return 0;
}

int main(){
	vector<string> filenames = readTextFile("src", "images.txt");

	vector<Dimensions> dims = vector<Dimensions>(5);
	int i = 0;
	for (string fullFilename : filenames){
		cout << "Displaying image: " << fullFilename << endl;
		displayImage(fullFilename, &(dims.at(i)));
		i++;
	}

	writeTextFile("result", "images_info.txt", dims);

	return 0;
}